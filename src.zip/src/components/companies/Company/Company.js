import React from 'react';
const company = (props) => {
    return (
        <div className="col-md-4">
            <div className="card">
                <div className="card-header">
                    {props.company.name}
                </div>
                <div className="card-body">
                    <p className="text-muted">{props.company.description}</p>
                </div>
                <div className="card-footer">Today's Price:${props.company.price}</div>
            </div>
        </div>

    )
}
export default company;