import React, { Component } from 'react';
import Company from './Company/Company';
class CompanyList extends Component {
    state = {
        companies: [
            { cid: 1, name: 'CTS', description: 'sdjdyhsauidhuassdhd dsauid', price: 500 },
            { cid: 2, name: 'Wipro', description: 'sdjdyhsauidhuassdhd dsauid', price: 400 },
            { cid: 3, name: 'Capgemini', description: 'sdjdyhsauidhuassdhd dsauid', price: 370 },
        ]
    }
    render() {
        let companyElements = this.state.companies.map(company => {
            return <Company key={company.cid} company={company} />
        })
        return (
            <div className="container mt-4">
                <div className="row">
                    {companyElements}
                </div>

            </div>
        )
    }
}
export default CompanyList;