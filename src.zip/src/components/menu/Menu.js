import React from 'react';
const menu = (props) => {
    return (
        <nav className="navbar navbar-expand navbar-dark bg-primary">
            <a href="#" className="navbar-brand">mStockApp</a>
            <button className="navbar-toggler" data-toggle="collapse" data-target="#navContent">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div id="navContent" className="collapse navbar-collapse">
                <ul className="navbar-nav d-flex justify-content-between">
                    {!props.isLoggedIn ? <li className="nav-item">
                        <a href="#" className="nav-link" onClick={() => props.selectedFeature('login')}>Login</a>
                    </li> : null}
                    {!props.isLoggedIn || props.isLoggedIn ? <li className="nav-item">
                        <a href="#" className="nav-link" onClick={() => props.selectedFeature('companies')}>Companies</a>
                    </li> : null}
                    {props.isLoggedIn ? <li className="nav-item">
                        <a href="#" className="nav-link">Watch List</a>
                    </li> : null}
                    {props.isLoggedIn ? <li className="nav-item">
                        <a href="#" className="nav-link">Compare Performance</a>
                    </li> : null}
                    {props.isLoggedIn ? <li className="nav-item">
                        <a href="#" className="nav-link" onClick={props.logout}>Logout</a>
                    </li> : null}
                </ul>
            </div>
        </nav>
    )
}
export default menu;