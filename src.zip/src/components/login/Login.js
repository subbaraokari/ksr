import React, { Component } from 'react';
class Login extends Component {
    state = {
        email: null,
        password: null
    }
    render() {
        return (
            <div className="row">
                <div className="col-md-4"></div>
                <div className="col-md-4">
                    <div className="form-group">
                        <label for="email">Email</label>
                        <input type="email" className="form-control" id="email" onChange={($event) => {
                            this.setState({
                                email: $event.target.value
                            });
                        }} />
                    </div>
                    <div className="form-group">
                        <label for="password">Password</label>
                        <input type="password" className="form-control" id="password" onChange={($event) => {
                            this.setState({
                                password: $event.target.value
                            });
                        }} />
                    </div>
                    <button className="btn btn-primary" onClick={() => this.props.login(this.state.email, this.state.password)}>Login</button>
                </div>
            </div>
        )
    }
}
export default Login;