import React, { Component } from 'react';
import CompanyList from './components/companies/CompanyList';
import Login from './components/login/Login';
import Menu from './components/menu/Menu';
class App extends Component {
  state = {
    featureSelected: 'login',
    isLoggedIn: false
  }
  changeFeatureHandler = (feature) => {
    this.setState({
      featureSelected: feature
    });
  }
  login = (username, password) => {
    if (username === 'ksrao' && password === 'ksrao@123') {
      this.setState({
        isLoggedIn: true
      })
    }
  }
  logout = () => {
    this.setState({
      isLoggedIn: false
    });
  }
  render() {
    let featureComponent = <Login login={this.login} />;
    if (this.state.featureSelected === 'login')
      featureComponent = <Login login={this.login} />;
    if (this.state.featureSelected === 'companies')
      featureComponent = <CompanyList />;
    return (
      <div>
        <Menu isLoggedIn={this.state.isLoggedIn} logout={this.logout} selectedFeature={this.changeFeatureHandler} />
        {featureComponent}
      </div>
    )
  }
}
export default App;